#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>

using namespace std;

inline int countSetBits(int n) {
    return __builtin_popcount(n);
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    int n;
    if (!(cin >> n)) return 0;

    int m = n / 2;

    vector<vector<int>> are_friends(m, vector<int>(m));

    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> are_friends[i][j];
        }
    }

    vector<vector<int>> dp(1 << m, vector<int>(m, -1));

    for (int i = 0; i < m; ++i) {
        dp[1 << i][i] = are_friends[0][i];
    }

    for (int mask = 1; mask < (1 << m) - 1; ++mask) {

        int pos = countSetBits(mask);

        if (pos >= m) continue;

        int best_generic_score = -1;
        for(int i=0; i<m; ++i) {
            if(dp[mask][i] > best_generic_score) {
                best_generic_score = dp[mask][i];
            }
        }

        if (best_generic_score == -1) continue; 
        for (int next = 0; next < m; ++next) {
            if (!((mask >> next) & 1)) {

                int prev_score = best_generic_score;

                if (next > 0 && ((mask >> (next - 1)) & 1)) {
                    if (dp[mask][next - 1] != -1) {
                        prev_score = max(prev_score, dp[mask][next - 1] + 1);
                    }
                }

                if (next < m - 1 && ((mask >> (next + 1)) & 1)) {
                    if (dp[mask][next + 1] != -1) {
                        prev_score = max(prev_score, dp[mask][next + 1] + 1);
                    }
                }

                int current_gain = 0;

                if (are_friends[pos][next]) current_gain++;

                current_gain++;

                int new_mask = mask | (1 << next);
                if (prev_score + current_gain > dp[new_mask][next]) {
                    dp[new_mask][next] = prev_score + current_gain;
                }
            }
        }
    }

    int full_mask = (1 << m) - 1;
    int max_happiness = 0;

    for (int i = 0; i < m; ++i) {
        max_happiness = max(max_happiness, dp[full_mask][i]);
    }

    cout << max_happiness << endl;

    return 0;
}
