#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <string>
#include <cmath>
#include <deque>
#include <cstring>
#include <iomanip>
#include <set>
#include <thread>
#include <algorithm>
#include <sstream>
#include <unordered_map>
#define _CRT_SECURE_NO_WARNINGS
#define all(x) x.begin(), x.end()
//vector<vector<int>> Ar(n, vector<int>(m, 0)); // n * m vector
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;
 
signed main() {
    int t;
    cin >> t;
 
    for (int TC = 0; TC < t; TC++) {
        int n;
        cin >> n;
        vector<ll> a(n);
        for (auto &x : a) cin >> x;
 
        vector<ll> prefix(n + 1, 0);
        for (int i = 0; i < n; ++i)
            prefix[i + 1] = prefix[i] + a[i];
 
        vector<ll> dp(n + 1, -INF);
        dp[0] = -INF;
        int ans = -INF;
        vector<pair<int,int>> Concurrent = {{0,0}},Upd;
        int negprefix = 0;
 
        for (int i = 0; i < n; i++) {
            negprefix-= a[i];
            Upd.push_back({negprefix,0});
            if(i > 0){
                dp[i] = max(dp[i],dp[i-1]-a[i-1]);
            }
            if(dp[i] != -INF){
                Concurrent.push_back({dp[i],0});
            }
            for(int j = 0;j<Concurrent.size();j++){
                Concurrent[j].first += a[i];
                Concurrent[j].second += a[i];
                int remain = prefix[n] - prefix[i+1];
                if(remain >= (Concurrent[j].second+1)/2) {
                    Upd.push_back(Concurrent[j]);
                }
            }
            for(int j = 0;j<Concurrent.size();j++){
                int needtocover = Concurrent[j].second;
                
                ll target_sum = prefix[i+1] + (needtocover+1)/2;
 
                auto it = lower_bound(all(prefix), target_sum);
                if (it != prefix.end()) {
                    int ind = it-prefix.begin();
                    int decrease = prefix[ind]-prefix[i + 1];
                    dp[ind] = max(dp[ind],Concurrent[j].first - decrease);
                    int decreastilltheend = prefix[n]-prefix[i + 1];
                    ans = max(ans,Concurrent[j].first - decreastilltheend);
                }
            }
            std::sort(all(Upd), [](const pair<int,int> &a, pair<int,int> &b)
            { 
                if(a.first == b.first){
                    return a.second < b.second;
                }
                return a.first > b.first;
            });
            int M = INF;
            Concurrent.clear();
            for(int j = 0;j<Upd.size();j++){
                pair<int,int> a = Upd[j];
                int val = a.second;
                if(a.second < M){
                    Concurrent.push_back(Upd[j]);
                }
                M = min(val,M);
            }
 
            Upd.clear();
        }
        for(int j = 0;j<Concurrent.size();j++){
            if(Concurrent[j].second==0){ans = max(ans,Concurrent[j].first);}
        }
        cout << ans << "\n";
    }
}

