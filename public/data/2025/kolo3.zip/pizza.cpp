#include <bits/stdc++.h>
using namespace std;

struct Node {
    int val; 
    Node *left, *right;
    int refcnt;      // number of references (parents + dp roots)

    Node(int v = 0, Node* L = nullptr, Node* R = nullptr)
    : val(v), left(L), right(R), refcnt(0) {}
};

static const int MAX_NODES = 20000000;

Node node_pool[MAX_NODES];
int pool_ptr = 0;
Node* free_list_head = nullptr;

inline Node* allocNode(int v = 0, Node* L = nullptr, Node* R = nullptr) {
    Node* x;
    if (free_list_head) {
        x = free_list_head;
        // reuse left as "next" in free list
        free_list_head = free_list_head->left;
    } else {
        x = &node_pool[pool_ptr++];
    }
    x->val = v;
    x->left = L;
    x->right = R;
    x->refcnt = 0;
    return x;
}

inline void inc_ref(Node* x) {
    if (x) x->refcnt++;
}

void dec_ref(Node* x) {
    if (!x) return;
    x->refcnt--;
    if (x->refcnt == 0) {
        Node* L = x->left;
        Node* R = x->right;
        // recycle this node into free list (reuse left as next)
        x->left = free_list_head;
        x->right = nullptr;
        x->val = 0;
        free_list_head = x;
        if (L) dec_ref(L);
        if (R) dec_ref(R);
    }
}

Node* build_zero_tree(int L, int R) {
    Node* node = allocNode(0, nullptr, nullptr);
    node->refcnt = 1;  // this pointer returned to caller

    if (L == R) {
        return node;
    }
    int M = (L + R) / 2;
    Node* left  = build_zero_tree(L, M);
    Node* right = build_zero_tree(M + 1, R);

    node->left  = left;
    node->right = right;
    inc_ref(left);
    inc_ref(right);

    return node;
}

int query(Node* root, int L, int R, int pos) {
    if (!root) return 0; // shouldn't happen, but safe
    if (L == R) return root->val;
    int M = (L + R) / 2;
    if (pos <= M) return query(root->left,  L, M, pos);
    else          return query(root->right, M + 1, R, pos);
}

Node* update(Node* root, int L, int R, int pos, int delta) {
    Node* node = allocNode(root->val, nullptr, nullptr);
    node->refcnt = 1; 
    if (L == R) {
        node->val += delta;
        return node;
    }

    int M = (L + R) / 2;
    if (pos <= M) {
        Node* newLeft = update(root->left, L, M, pos, delta);
        node->left = newLeft;
        node->right = root->right;
        if (node->right) inc_ref(node->right);
    } else {
        Node* newRight = update(root->right, M + 1, R, pos, delta);
        node->right = newRight;
        node->left = root->left;
        if (node->left) inc_ref(node->left);
    }

    return node;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, k;
    if (!(cin >> n >> k)) {
        return 0;
    }
    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];

    if (k >= n){
        cout << a[0] << "\n";
        return 0;
    }
    if (k <= 0) {
        cout << 0 << "\n";
        return 0;
    }
    if (k == 1) {
        cout << 0 << "\n";
        return 0;
    }


    Node* zero_root = build_zero_tree(0, k - 1);

    vector<Node*> dp_next(k, nullptr), dp_cur(k, nullptr);

    for (int t = 0; t < k; ++t) {
        dp_next[t] = zero_root;
        inc_ref(zero_root);
    }

    for (int i = n - 1; i >= 0; --i) {
        for (int t = 0; t < k; ++t) {
            if (dp_cur[t]) {
                dec_ref(dp_cur[t]);
                dp_cur[t] = nullptr;
            }
        }

        for (int t = k - 1; t >= 0; --t) {
            if (t == k - 1) {
                Node* best = dp_next[0];  
                inc_ref(best);             
                dp_cur[t] = best;
            } else {
                int t_next = t + 1;

                Node* pass_root = dp_cur[t_next]; 

                Node* suffix_root = dp_next[t_next];
                Node* take_root   = update(suffix_root, 0, k - 1, t, a[i]);

                int self_pass = query(pass_root, 0, k - 1, t);
                int self_take = query(take_root, 0, k - 1, t);

                Node* best = nullptr;

                if (self_take > self_pass) {
                    best = take_root;
                    dp_cur[t] = best;
                } else if (self_take < self_pass) {
                    best = pass_root;
                    inc_ref(best);
                    dp_cur[t] = best;
                    dec_ref(take_root);
                } else {
                    int p1_pass = query(pass_root, 0, k - 1, 0);
                    int p1_take = query(take_root, 0, k - 1, 0);
                    if (p1_take >= p1_pass) {
                        best = take_root;
                        dp_cur[t] = best;
                    } else {
                        best = pass_root;
                        inc_ref(best);
                        dp_cur[t] = best;
                        dec_ref(take_root);
                    }
                }
            }
        }

        for (int t = 0; t < k; ++t) {
            if (dp_next[t]) {
                dec_ref(dp_next[t]);
                dp_next[t] = nullptr;
            }
        }

        for (int t = 0; t < k; ++t) {
            dp_next[t] = dp_cur[t];
            dp_cur[t]  = nullptr;
        }
    }

    Node* start_root = dp_next[0];
    int answer_first_player = query(start_root, 0, k - 1, 0);

    cout << answer_first_player << "\n";

    for (int t = 0; t < k; ++t) {
        if (dp_next[t]) {
            dec_ref(dp_next[t]);
            dp_next[t] = nullptr;
        }
    }

    return 0;
}

