#include <bits/stdc++.h>
#define N 5005
using namespace std;

int n, m, n1, n2, n3;
int c[N], f, idx;
int siza[N], sizb[N];
int c1, c2;
int dp[N][N], vis[N], ans[N], pos[N];
vector<int> e[N];

void dfs(int u, int lst) {
    c[u] = 3 - lst;
    if (c[u] == 1) ++c1;
    else ++c2;

    for (int v : e[u]) {
        if (!c[v]) {
            dfs(v, c[u]);
        } else if (c[u] == c[v]) {
            f = 1;
        }
    }
}

void dfs2(int u, int k) {
    vis[u] = 1;
    if (c[u] == k) ans[u] = 2;

    for (int v : e[u]) {
        if (!vis[v]) {
            dfs2(v, k);
        }
    }
}

signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    cin >> n >> m >> n1 >> n2 >> n3;

    for (int i = 1; i <= m; ++i) {
        int u, v;
        cin >> u >> v;
        e[u].push_back(v);
        e[v].push_back(u);
    }

    for (int i = 1; i <= n; ++i) {
        if (c[i]) continue;

        c1 = c2 = 0;
        dfs(i, 1);
        siza[++idx] = c1;
        sizb[idx] = c2;
        pos[idx] = i;
    }

    if (f) {
        cout << "-1\n";
        return 0;
    }

    memset(dp, -1, sizeof(dp));
    dp[0][0] = 0;

    for (int i = 1; i <= idx; ++i) {
        for (int j = 0; j <= n; ++j) {

            if (j >= siza[i] && dp[i - 1][j - siza[i]] != -1) {
                dp[i][j] = 0;
            }
            if (j >= sizb[i] && dp[i - 1][j - sizb[i]] != -1) {
                dp[i][j] = 1;
            }

        }
    }

    if (dp[idx][n2] == -1) {
        cout << -1 <<"\n";
        return 0;
    }


    int now = n2;
    for (int i = idx; i >= 1; --i) {
        dfs2(pos[i], dp[i][now] + 1);

        if (!dp[i][now]) {
            now -= siza[i];
        } else {
            now -= sizb[i];
        }
    }

    for (int i = 1; i <= n; ++i) {
        if (!ans[i]) {
            if (n1) {
                ans[i] = 1;
                --n1;
            } else {
                ans[i] = 3;
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        cout << ans[i] <<" ";
    }
    cout <<"\n";
    return 0;
}


