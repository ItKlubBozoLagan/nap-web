#include <stdio.h>
 
int main() {
	static int pp[30];
	int n, a, b, p, q, ans;
 
	scanf("%d", &n);
	p = 0;
	while (n--) {
		scanf("%d", &a);
		q = p ^= a;
		for (b = 0; b < 30; b++)
			if (q & 1 << b)
				q ^= pp[b];
		if (q) {
			b = 0;
			while (!(q & 1 << b))
				b++;
			pp[b] = q;
		}
	}
	ans = -1;
	if (p) {
		ans = 0;
		for (b = 0; b < 30; b++)
			if (pp[b])
				ans++;
	}
	printf("%d\n", ans);
	return 0;
}
