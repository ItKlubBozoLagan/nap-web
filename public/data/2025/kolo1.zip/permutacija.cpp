#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <string>
#include <cmath>
#include <deque>
#include <cstring>
#include <iomanip>
#include <set>
#include <thread>
#include <algorithm>
#include <sstream>
#include <unordered_map>
#define _CRT_SECURE_NO_WARNINGS
#define all(x) x.begin(), x.end()
//vector<vector<int>> Ar(n, vector<int>(m, 0)); // n * m vector
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;
 
vector<int> Ans;
int totalqueries = 0;
int query(int i, int j){
    totalqueries++;
    cout << "? " << i+1 << " " << j+1 << "\n";
    cout.flush();
    int ret;
    cin >> ret; 
    return ret;
}
 
 
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
 
    int t;
    cin >> t;
 
    for (int TC = 0; TC < t; TC++) {
        totalqueries = 0;
        int n;
        cin >> n;
        vector<int> Ans;
        for (int i = 0; i < n; i++) {
            Ans.push_back(0);
        }
        vector<pair<int,int>> Pairs;
 
        for (int i = 1; i < n; i++) {
            int d = query(0,i);
            Pairs.push_back({d,i});
        }
        sort(all(Pairs));
        if(n==1){
            cout << "! 1\n! 1\n";
            cout.flush();
            continue;
        }
        int mind = Pairs[n-2].second;
        int mdif = Pairs[n-2].first+1;
        Ans[mind] = 1;
        Ans[0] = mdif;
        for (int i = 0; i < n-1; i++) {
            if(i < n-2){
                if(Pairs[i].first==Pairs[i+1].first){
                    int d = query(mind,Pairs[i].second);
                    Ans[Pairs[i].second] = d+1;
                    Ans[Pairs[i+1].second] = 2*mdif-(d+1);
                    i++;
                    continue;
                }
            }
            Ans[Pairs[i].second] = mdif - Pairs[i].first;
        }
        cout << "! ";
        for (int i = 0; i < n; i++) {
            cout << Ans[i] << " ";
        }
        cout << "\n";
        cout << "! ";
        for (int i = 0; i < n; i++) {
            cout << n - Ans[i]+1 << " ";
        }
        cout << "\n";
        cout.flush();
    }
 
}
