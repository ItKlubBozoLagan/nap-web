#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <string>
#include <cmath>
#include <deque>
#include <cstring>
#include <iomanip>
#include <set>
#include <thread>
#include <algorithm>
#include <sstream>
#include <unordered_map>
#define _CRT_SECURE_NO_WARNINGS
#define all(x) x.begin(), x.end()
//vector<vector<int>> Ar(n, vector<int>(m, 0)); // n * m vector
using namespace std;
#define ll long long
#define int ll
#define ld double long

#define int long long
const int MOD = 1e9 + 7;
const int N = 5e3 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;
 
 
ll gcd(ll a, ll b)
{
    if (b == 0) return a;
    return gcd(b, a % b);
}
 
// Computes the Möbius function up to 'n'
vector<int> is_prime(N + 1, 1);
void computeMobius(int n, vector<int>& mu) {
    
    mu[0] = 0;
    mu[1] = 1;
 
    for (int i = 2; i <= n; ++i) {
        if (is_prime[i]) {
            for (int j = i; j <= n; j += i) {
                mu[j] *= -1;
                is_prime[j] = 0;
            }
            
            // Not square-free
            for (int j = i * i; j <= n; j += i * i) {
                mu[j] = 0; 
            }
        }
    }
}
 
int Cnt[N];
int Div[N];
 
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    vector<int> mu(N+1,1);
 
    computeMobius(N,mu);
 
    int t;
    cin >> t;
 
 
    for (int TC = 0; TC < t; TC++) {
        int n;
        cin >> n;
        vector<int> Ar;
 
        int maxa = 0;
        for (int i = 0; i < n; i++) {
            int a;
            cin >> a;
            Ar.push_back(a);
            maxa = max(maxa,a);
        }
        for (int i = 0; i < maxa+1; i++) {
            Cnt[i] = 0;
            Div[i] = 0;
        }
        for (int i = 0; i < n; i++) {
            Cnt[Ar[i]]++;
        }
        int ans = 0;
        for (int k = 1; k < maxa+1; ++k){
            for (int j = k; j < maxa+1; j += k){
                Div[k] += Cnt[j];
            }
        }
        
        int total = n*(n-1)*(n-2)/6;
 
        int noncoprimetriples = 0; // triplets where at least one pair has gcd = 1
        int coprimetriples = total; //triplets with their whole gcd > 1
        for (int k = 1; k < maxa+1; k++) {
            int count = Div[k];
 
            if (mu[k] == 0 || count < 2) continue;
            
            int triples = count * (count - 1) *(count-2)/ 6;
            coprimetriples -= mu[k] * triples;
        }
        
        for (int i = 1; i < maxa+1; i++){
            int a = Cnt[i]; //cnt of smallest number in triplet
            if(a == 0){continue;}
            int Cnt2[maxa+1];
            Cnt2[0] = 0;
            int b = 0; //cnt of numbers which have gcd with the smallest number equal to 1
            int c = 0; //cnt of numbers which have gcd with the smallest number bigger than 1
 
            for (int k = 1; k < maxa+1; ++k){
                Div[k] = 0;
                Cnt2[k] = 0;
                if(k > i){
                    if(gcd(i,k)!=1){
                        Cnt2[k] = Cnt[k];
                        c+=Cnt[k];
                    }
                    else{
                        b+=Cnt[k];
                    }
                }
            }
            for (int k = 1; k < maxa+1; ++k){
                for (int j = k; j < maxa+1; j += k){
                    Div[k] += Cnt2[j];
                }
            }
            int totalpairs = 0;
            for (int k = 1; k < maxa+1; k++) {
                int count = Div[k];
 
                if (mu[k] == 0 || count < 1) continue;
                
                int pairs = count * (count - 1) /2;
                totalpairs+= mu[k] * pairs;
            }
            // we need to consider 5 different ways a triplet is made when i is the smallest number
            // cnt[i] = a | cnt[x] = b | cnt[y] = c
            // number x from set X is coprime with i, number y from set Y is not coprime with i
            // totalpairs denotes the number of pairs that are coprime in set Y among each other
 
            int add1 = a * b * (a-1)/2; // (i,i,x) where gcd(x,i) = 1
            int add2 = a * b * (b-1)/2; // (i,x1,x2) where gcd(x,i) = 1
            int add3 = a*b*c; //(i,x,y) where gcd(x,i) = 1
            int add4 = a*totalpairs; //(i,y1,y2) where gcd(y1,y2) = 1
            int finaladd = add1+add2+add3+add4;
            if(i == 1){finaladd+= a*(a-1)*(a-2)/6;} //special case where (i,i,i) is valid
            noncoprimetriples+= finaladd;
        }
 
 
        cout << total-noncoprimetriples-coprimetriples << "\n";
    }
 
}

