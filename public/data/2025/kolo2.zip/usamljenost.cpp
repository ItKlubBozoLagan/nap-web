#include <bits/stdc++.h>
using namespace std;

vector<int> bfs(int start, const vector<vector<int>>& adj) {
    int n = adj.size();
    vector<int> dist(n, -1);
    queue<int> q;
    dist[start] = 0;
    q.push(start);
    while (!q.empty()) {
        int u = q.front(); q.pop();
        for (int v : adj[u]) {
            if (dist[v] == -1) {
                dist[v] = dist[u] + 1;
                q.push(v);
            }
        }
    }
    return dist;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n);
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        --u; --v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    int a, b, c;
    cin >> a >> b >> c;
    --a; --b; --c;

    vector<int> da = bfs(a, adj);
    vector<int> db = bfs(b, adj);
    vector<int> dc = bfs(c, adj);

    long long best = LLONG_MAX;

    auto consider = [&](const vector<int>& d1, const vector<int>& d2, const vector<int>& d3) {
        for (int v = 0; v < n; ++v) {
            if (d1[v] == -1 || d2[v] == -1 || d3[v] == -1) continue;
            int t1 = max(d1[v], d2[v]);
            int t2 = (t1 >= d3[v]) ? t1 : (t1 + d3[v] + 1) / 2;
            long long total = 2LL * t1 + t2;
            best = min(best, total);
        }
    };

    consider(da, db, dc);
    consider(da, dc, db);
    consider(db, dc, da);

    cout << best << "\n";
    return 0;
}

