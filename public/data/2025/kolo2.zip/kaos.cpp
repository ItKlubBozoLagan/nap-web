#include<bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n, k;
const int MAXN = 20;
const int mod = 1e9+7;

ll a[MAXN];
ll b[MAXN];

ll dp[1<<MAXN];

long long mod_pow(long long base, long long exp) {
    base %= mod;
    long long res = 1 % mod;
    while (exp > 0) {
        if (exp & 1) res = (__int128)res * base % mod;
        base = (__int128)base * base % mod;
        exp >>= 1;
    }
    return res;
}

// modular inverse (for prime mod): returns a^{-1} mod mod, assuming gcd(a, mod) = 1
long long mod_inv(long long x) {
    return mod_pow(x, mod - 2); // Fermat's little theorem, mod must be prime
}

int main(){
    cin >>n >>k;

    ll sum = 0;
    for (int i = 0; i < n; ++i){
        cin >>a[i];
    }

    vector<ll> fact(n + 1, 1);
    for (int i = 1; i <= n; i++) {
        fact[i] = fact[i - 1] * i % mod;
    }

    for (int i = 0; i < n; ++i){
        b[i] = k-a[i];
        sum += b[i];
    }
    int cnt = sum/k;
    dp[0] = 1;
    for (int mask = 0; mask < (1<<n); ++mask){
        ll sum = 0;
        for (int i = 0; i < n; ++i){
            if ((mask&(1<<i))){
                sum += b[i];
                sum %= k;
            }
        }
        for (int i = 0; i < n; ++i){
            if (!(mask&(1<<i))){
                if (sum + b[i] > k)continue;
                dp[mask|(1<<i)] += dp[mask];
                dp[mask|(1<<i)] %= mod;
            }
        }
    }


    ll half = (1+mod)/2;
    ll sol = dp[(1<<n)-1];
    for (int i = 0; i < cnt; ++i){
        sol *= half;
        sol %= mod;
    }

    sol *= mod_inv (fact[cnt]);
    sol %= mod;
    cout <<sol <<"\n";

return 0;
}

