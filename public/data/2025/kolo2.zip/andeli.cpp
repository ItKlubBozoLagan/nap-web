#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <set>
#include <thread>
#include <queue>
#include <deque>
#include <cstring>
#define _CRT_SECURE_NO_WARNINGS
#define all(x) x.begin(), x.end()
//#pragma GCC optimize("Ofast,unroll-loops")
//#pragma GCC target("avx,avx2,fma")
//vector<vector<int>> Ar(n, vector<int>(m, 0)); // n * m vector
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;
 
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    for (int TC = 0; TC < t; TC++) {
        int n;
        cin >> n;
        int totalsurface = 0;
        for(int i = 0;i<n;i++){
            int a,b;
            cin >> a >> b;
            totalsurface += a*b;
        }
        vector<int> Squares;
        for(int i = 1; i*i <= totalsurface; i++ ){
            Squares.push_back(i*i);
        }
        reverse(all(Squares));
        vector<int> dp;
        dp.push_back(0);
        for(int i = 0;i<Squares.size();i++){
            int sq = Squares[i];
            for(int j = 0;j<dp.size();j++){
                int val = dp[j] + sq;
                if(val <= totalsurface){
                    dp.push_back(val);
                }
            }
            sort(all(dp));
            dp.erase(unique(all(dp)), dp.end());
            if(dp.back() == totalsurface){
                cout << sq << "\n";
                break;
            }
        }
 
 
    }
}

