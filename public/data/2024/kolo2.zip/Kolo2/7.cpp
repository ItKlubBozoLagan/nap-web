#include <bits/stdc++.h>
using namespace std;

typedef int ll;
const int N = 1e5 + 2;

int n, q, ans[N];
ll a[N];
set<ll> s[N];
vector<int> adj[N];

void merge(set<ll>& X, set<ll>& Y) {
if (X.size() < Y.size()) swap(X, Y);
for (auto it = Y.begin(); it != Y.end(); ++it) X.insert(*it);
}

void dfs(int node, int anc = -1) {
s[node].insert(a[node]);

int M = 0, S = 0;
for (int x : adj[node]) {
if (x == anc) continue;
dfs(x, node);

int val = s[x].size();
if (val >= M) {
S = M;
M = val;
} else S = max(S, val);

merge(s[node], s[x]);
}

++ans[s[node].size()];

if (node) --ans[M];
else --ans[S];
}

int main() {
ios_base::sync_with_stdio(false); cin.tie(0);

cin >> n >> q;
for (int i = 0; i < n; ++i) cin >> a[i];

for (int i = 1; i < n; ++i) {
int u, v;
cin >> u >> v, --u, --v;
adj[u].push_back(v);
adj[v].push_back(u);
}

dfs(0);

for (int i = n - 1; i >= 0; --i) ans[i] += ans[i + 1];

while (q--) {
int k;
cin >> k;

cout << ans[k] << "\n";
}
}
