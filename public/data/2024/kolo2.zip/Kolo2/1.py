n = int(input())
if n == 25:
    print("Sretan Božić!")
else:
    print("Još je " + str(25 - n) + " dana do Božića.")
