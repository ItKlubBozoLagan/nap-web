n = int(input())
m = int(input())

sol = ["." * (m + 2)]

sol.append("." * ((m // 2)) + "\\/" + "." * ((m // 2)))
sol.append(".+" + (m - 2) * "-" + "+.")

for i in range(0, (n - 3) // 2):
    sol.append(".|" + "." * ((m // 2) - 2) + "||" + ((m // 2) - 2) * "." + "|.")

sol.append(".|" + "=" * ((m // 2) - 2) + "||" + ((m // 2) - 2) * "=" + "|.")

for i in range(0, (n - 3) - ((n - 3) // 2)):
    sol.append(".|" + "." * ((m // 2) - 2) + "||" + ((m // 2) - 2) * "." + "|.")
sol.append(".+" + (m - 2) * "-" + "+.")
sol.append("." * (m + 2))

for i in sol:
    print(i)

