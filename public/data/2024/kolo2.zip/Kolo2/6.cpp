#include<bits/stdc++.h>

using namespace std;
using i64 = int64_t;
using u32 = uint32_t;
using u64 = uint64_t;
using u128 = __uint128_t;
typedef long long ll;
const int mod = 1e9+7;
template <typename T, auto &M> struct Mod {
  using V = conditional_t<sizeof(T) <= 4, u64, u128>;
  static V inv(V x, V m) { return x > 1 ? m - inv(m % x, x) * m / x : 1; }
  make_unsigned_t<T> x;
  Mod() : x(0) {}
  template <typename U> Mod(U y) : x(y % M) { x >= M ? x += M : x; }
  operator T() const { return x; }
  Mod operator-() const { return Mod() -= *this; }
  template <typename U> Mod operator+(U rhs) const { return Mod(*this) += rhs; }
  template <typename U> Mod operator-(U rhs) const { return Mod(*this) -= rhs; }
  template <typename U> Mod operator*(U rhs) const { return Mod(*this) *= rhs; }
  template <typename U> Mod operator/(U rhs) const { return Mod(*this) /= rhs; }
  Mod &operator+=(Mod rhs) { return (x += rhs.x) >= M ? x -= M : x, *this; }
  Mod &operator-=(Mod rhs) { return (x -= rhs.x) >= M ? x += M : x, *this; }
  Mod &operator*=(Mod rhs) { return x = x * V(rhs.x) % M, *this; }
  Mod &operator/=(Mod rhs) { return x = x * inv(rhs.x, M) % M, *this; }
  template <typename U> Mod pow(U y) const { // O(log y) | 0^(-inf,0] -> 1
    Mod ans(1), base(*this);
    for (auto e = y < 0 ? ~y + u128(1) : +y; e; e >>= 1, base *= base) {
      e & 1 ? ans *= base : ans;
    }
    return y < 0 ? Mod(1) /= ans : ans;
  }
};
using mint = Mod<int, mod>;
//using mint = double;
const int MAXN = 4e6;

int n;
mint d[3][MAXN];
mint f[3][MAXN];
mint sol = 1;


void bfft (int l, mint *arr, mint *ft){
    //cout <<l <<"\n";
    if (l == 2){
        //cout <<"HERE\n";
        ft[0] = (mint)(arr[0]+arr[1])/2;
        ft[1] = (mint)(arr[0]-arr[1])/2;
        return;
    }
    //cout <<"HERE1\n";
    int nl = l/2;
    //cout <<"HERE2\n";
    bfft (nl, arr, ft);
    //cout <<l <<"out first\n";
    bfft (nl, arr+nl, ft+nl);
    //cout <<l <<"out second\n";
    for (int i = 0; i < nl; ++i){
        ft[i] = (mint)(ft[i]+ft[i+nl])/2;
        ft[i+nl] = (mint)(ft[i]-ft[i+nl]);
    }
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >>n;
    int m = n;
    n = (1<<n);
    for (int i = 0; i < 3; ++i){
        for (int j = 0; j < n; ++j){
            int a;
            cin >>a;
            if (a == 0)a = -1;
            d[i][j] = mint (a);
        }

        bfft (n, d[i], f[i]);
    }
    sol /= 4;
    /*
    for (int i = 0; i < 3; ++i){
        for (int j = 0; j < n; ++j){
            cout <<f[i][j] <<" ";
        }
        cout <<"\n";
    }
    cout <<sol <<"\n";
    */
    for (int i = 0; i < n; ++i){
        mint cf = 1;
        int sgn = 1;
        for (int j = 0; j < m; ++j){
            if((i&(1<<j))){
                cf /= 3;
                sgn *= -1;
            }
        }
        //cout <<i <<" " <<cf <<"\n";
        mint add = f[0][i]*f[1][i];
        add += f[0][i]*f[2][i];
        add += f[1][i]*f[2][i];

        add *= cf;
        //cout <<add <<" ";
        add *= sgn;
        add /= 4;
        //cout <<add <<"\n";
        sol += add;

    }

    cout <<sol <<"\n";



return 0;
}
/*
3
0 1 1 0 0 0 0 0
0 0 0 1 0 0 1 1
0 1 1 0 1 1 1 1

*/

