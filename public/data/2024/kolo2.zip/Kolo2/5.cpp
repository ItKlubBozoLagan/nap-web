#include <bits/stdc++.h>

#define F first
#define S second
#define all(x) x.begin(), x.end()
#define pb push_back
#define FIO ios_base::sync_with_stdio(false); cin.tie(0); cout.tie(0)

using namespace std;

typedef long long ll;
typedef pair <ll, ll> pii;

string s = "0";

int main () {
	FIO;
	int n; cin >> n;
	for (int i = 1; i < n; i++) {
		int a; cin >> a;
		if (a > 0) s += s[0];
		else s += '1';
	}
	cout << s;

	return 0;
}

