#include<bits/stdc++.h>

using namespace std;

void solve() {
    int n, k, mx, kx;
    cin >> n >> k >> kx >> mx;
    int a[n];
    for(int i = 0; i < n; ++i) a[i] = 0;
    for(int i = 0; i < k; ++i) for(int j = 0; j < n; ++j) {
        int x;
        cin >> x;
        a[j] += x;
    }

    int pos = 1;
    for(int i = 0; i < n; ++i) if(a[i] > (k - kx + 1) * mx) pos++;

    cout << pos << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
    return 0;
}
