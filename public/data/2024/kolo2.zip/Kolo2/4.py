from math import gcd
import sys

sys.set_int_max_str_digits(100000)

x = input();
lim = int(input())

if '.' not in x:
    if int(x)>lim or int(x)<1:
        print (-1)
    else:
        print (1)
    exit(0)

i, frac = x.split('.')
if int(frac) == 0:
    if int(i)>lim or int(i)<1:
        print (-1)
    else:
        print (1)
    exit (0)
s = i+frac
num = 0
for ii in s:
    num = num*10+int(ii)

den = 10 ** len(frac)

div = gcd(num, den)
num //= div
den //= div


if int(i)>=lim or int(i)==0:
    print (-1)
else:
    print (int(den))

