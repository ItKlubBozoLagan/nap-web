#include<bits/stdc++.h>

using namespace std;

const int MAXN = 2e6;
int n;
int f[MAXN];
int graph[MAXN];

int cnt[MAXN];
set<int> uns[MAXN];
int parent[MAXN];
int depth[MAXN];
int len[MAXN];

int chain[MAXN];
int start[MAXN];

bool isc[MAXN];

int find (int x){
    if (parent[x] == x){
        return x;
    }
    int tmp = parent[x];
    parent[x] = find (parent[x]);
    depth[x] += depth[tmp]-1;
    return parent[x];
}

int spoji (int x, int y){
    int X = find (x); //x=X ako nije ciklus
    int Y = find (y);

    if (X == Y) return -1;
    parent[X] = Y;
    depth[X] = depth[y]+1;
//    cout <<X <<" " <<Y <<" " <<len[X] <<" " <<y <<" " <<depth[y] <<"\n";
    int d = len[X]+depth[y];
    len[Y]= max (d, len[Y]);
    return len[Y];
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >>n;

    for (int i = 0; i < n; ++i){
        cin >>f[i];
        f[i]--;
        cnt [f[i]]++;
    }

    for (int i = 0; i < n; ++i){
        uns[i].insert (i);
        parent[i] = i;
        depth[i] = 1;
        if (cnt[i] <= 1)isc[i] = 1;
        len[i] = 1;
        start[i] = i;
    }
    int maxi = 1;
    int res;

    for (int i = n-1; i > -1; --i){
        if (res == -1){
            cout <<-1 <<"\n";
            continue;
        }

        res = spoji (i, f[i]);
        if (res == -1){
            cout <<-1 <<"\n";
            continue;
        }
        maxi = max (maxi, res);
        cout <<maxi-1 <<"\n";
    }



return 0;
}
/*
9
8 1 2 2 2 4 3 7 7

5
2 3 4 5 1
*/

