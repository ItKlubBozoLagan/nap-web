#include<iostream>

using namespace std;

const int MAXN = 505;

int n;
char mat[MAXN][MAXN];

int calc (int start, int d){
    int res = 0;
    if (start > d)return -1000000000;
    for (int i = 0; i < d; ++i){
        res += start-i;
    }
    return res;
}

int x1 = -1, y1, x2, y2;
void draw (int start, int d){
    int cur = x1-1;
    for (int i = y1; i <= y2; ++i){
        if (start < 0){
            for (int j = 0; j < -start; ++j){

                if (cur < n && cur > -1)mat[cur][i] = 'v';
                cur++;
            }
        }else if (start == 0){
            if (cur < n && cur > -1)mat[cur][i] = '_';
            cur++;
        }else{
            for (int j = 0; j < start; ++j){
                if (cur < n && cur > -1)mat[cur][i] = '^';
                cur--;
            }
        }
        start--;

    }

    for (int i = 0; i < n; ++i){
        for (int j = 0; j < n; ++j){
            cout <<mat[i][j];
        }
        cout <<"\n";
    }

}

int main(){
    cin >>n;


    for (int i = 0; i < n; ++i){
        string s;
        cin >>s;
        for (int j = 0; j < n; ++j){
            if (s[j] == '#'){
                if (x1 == -1){
                    x1 = i;
                    y1 = j;
                }else{
                    x2 = i;
                    y2 = j;
                }
            }
            mat[i][j] = s[j];
        }
    }

    if (y1 > y2){
        swap (y1, y2);
        swap (x1, x2);
    }
    int d = y2-y1+1;
    for (int i = 1; i < n; ++i){
        if (calc (i, d) == x1-x2){
            draw (i, d);
            return 0;
        }
    }
    cout <<-1 <<"\n";

    return 0;
}
/*
11
...........
...........
...........
...........
...........
...........
...........
...........
...........
...........
#.....#....


10 10
...........
...........
...........
...-.......
..^.v......
.^...v.....
.^...v.....
^.....v....
^.....v....
^.....v....
#.....#....

*/

