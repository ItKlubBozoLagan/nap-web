#include<bits/stdc++.h>

using namespace std;
const int MAXN = 200002;
int n;
vector<int> v;
vector<set<int>> q;
set<int> query(){
    cout <<"? "<<v.size() <<" ";
    set<int> s;
    for (auto it : v){
        cout <<it <<" ";
    }
    cout <<endl;
    for (int i = 0; i < v.size(); ++i){
        cin >>v[i];
        s.insert (v[i]);
    }
    return s;
}
bool bio[MAXN];
vector<vector<int>> rows;
int niz[MAXN];
int main(){
    int m;
    cin >>m;
    while (m > 0){
        m/=2;
        n++;
    }

    for (int i = 1; i < n; ++i){
        v.clear();
        for (int j = 1; j < (1<<i); ++j){
            v.push_back (j);
        }

        q.push_back(query());
    }
    for (int i = 1; i < n; ++i){
        int cur = 1;
        v.clear();
        for (int j = 1; j < 1<<n; ++j)bio[j] = 0;
        for (int j = 0; j < n; ++j){
            if (j <= i){
                for (int k = (1<<j); k < (1<<(j+1)); ++k){
                    if (i == j && k%2 == 1)continue;
                    v.push_back (k);
                    bio[k] = 1;
                }
                continue;
            }
            for (int k = (1<<j); k < (1<<(j+1)); ++k){
                if (!bio[k/2]){
                    continue;

                }
                v.push_back (k);
                bio[k] = 1;
            }
        }
        q.push_back (query());
    }
    for (int j = 0; j < (1<<n); ++j)bio[j] = 0;
    niz[1] = *q[0].begin();
    for (int i = n-1; i > 0; --i){
        vector<int> row;
        for (auto it : q[i-1]){
            bio[it] = 1;
        }
        for (int j = 1; j < (1<<n); ++j){
            if (!bio[j]){
                row.push_back (j);
                bio[j] = 1;
            }
        }
        for (auto it : q[i-1]){
            bio[it] = 0;
        }
        int ord[row.size()];
        for (int j = 0; j < row.size(); ++j)ord[j] = 0;
        for (auto it : row){
            int poz = 0;
            for (int j = 0; j < i; ++j){
                if (q[n-1+j].count(it))continue;
                poz += 1<<(i-1-j);
            }
            ord[poz] = it;
        }
        for (int j = (1<<i); j < 1<<(i+1); ++j)niz[j] = ord[j-(1<<i)];

    }
    cout <<"! ";
    for (int i = 1; i < (1<<n); ++i){
        cout <<niz[i] <<" ";
    }
return 0;
}

