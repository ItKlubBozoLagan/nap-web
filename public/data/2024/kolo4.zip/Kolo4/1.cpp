#include<bits/stdc++.h>

using namespace std;

int n, m;

int main(){
    cin >>n >>m;

    if (n < m){
        cout <<"sturka\n";
    }else{
        int r = min (2*m-n, m+4-n);
        if (r <= 0) cout <<"W\n";
        else cout <<"r" <<"\n";
    }

return 0;
}

