#include <bits/stdc++.h>
using namespace std;

const long long MOD = 1000000007;

long long modexp(long long base, long long exp) {
    long long result = 1;
    base %= MOD;
    while(exp > 0){
        if(exp & 1)
            result = (result * base) % MOD;
        base = (base * base) % MOD;
        exp >>= 1;
    }
    return result;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m, k;
    cin >> n >> m >> k;

    vector<bool> rowHas(n+1, false), colHas(m+1, false);
    for (int i = 0; i < k; i++){
        int r, c;
        cin >> r >> c;
        rowHas[r] = true;
        colHas[c] = true;
    }

    int uncoveredRows = 0, uncoveredCols = 0;
    for (int i = 1; i <= n; i++){
        if(!rowHas[i])
            uncoveredRows++;
    }
    for (int j = 1; j <= m; j++){
        if(!colHas[j])
            uncoveredCols++;
    }

    if(uncoveredRows == 0 && uncoveredCols == 0){
        cout << 1 << "\n";
        return 0;
    }

    int maxVal = 200001;
    vector<long long> fact(maxVal+1), invfact(maxVal+1);
    fact[0] = 1;
    for (int i = 1; i <= maxVal; i++){
        fact[i] = (fact[i-1] * i) % MOD;
    }
    auto modinv = [&](long long x) {
        return modexp(x, MOD-2);
    };
    invfact[maxVal] = modinv(fact[maxVal]);
    for (int i = maxVal; i > 0; i--){
        invfact[i-1] = (invfact[i] * i) % MOD;
    }
    auto nCr = [&](int N, int R) -> long long {
        if(R < 0 || R > N) return 0;
        return ((fact[N] * invfact[R]) % MOD * invfact[N-R]) % MOD;
    };

    long long ans = 0;
    if(uncoveredRows == uncoveredCols){
        ans = fact[uncoveredRows] % MOD;
    }
    else if(uncoveredRows < uncoveredCols){
        for (int i = 0; i <= uncoveredRows; i++){
            long long term = nCr(uncoveredRows, i);
            long long ways = modexp(n - i, uncoveredCols);
            term = (term * ways) % MOD;
            if(i % 2 == 1)
                term = (MOD - term) % MOD;
            ans = (ans + term) % MOD;
        }
    }
    else { // uncoveredRows > uncoveredCols
        for (int i = 0; i <= uncoveredCols; i++){
            long long term = nCr(uncoveredCols, i);
            long long ways = modexp(m - i, uncoveredRows);
            term = (term * ways) % MOD;
            if(i % 2 == 1)
                term = (MOD - term) % MOD;
            ans = (ans + term) % MOD;
        }
    }

    cout << ans % MOD << "\n";
    return 0;
}

