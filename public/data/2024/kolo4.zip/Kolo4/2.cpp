#include <iostream>
#include <unordered_map>
#include <vector>
#include <iomanip>

using namespace std;

int main() {
    int n, m;
    cin >> n >> m;

    unordered_map<string, unordered_map<string, double>> carine;

    for (int i = 0; i < m; i++) {
        string drzava1, drzava2;
        int postotak;
        cin >> drzava1 >> drzava2 >> postotak;
        carine[drzava1][drzava2] = postotak / 100.0;
        carine[drzava2][drzava1] = postotak / 100.0;  // Carina je obostrana
    }

    int k;
    cin >> k;

    vector<string> put(k);
    for (int i = 0; i < k; i++) {
        cin >> put[i];
    }

    double ukupna_carina = 1.0; // Počinje s osnovnom vrijednošću (1.0 znači 0% carina)

    for (int i = 1; i < k; i++) {
        string prethodna = put[i - 1];
        string trenutna = put[i];

        if (carine[prethodna].find(trenutna) == carine[prethodna].end()) {
            carine[prethodna][trenutna] = 0.0;
        }

        ukupna_carina *= (1.0 + carine[prethodna][trenutna]);
    }

    cout << fixed << setprecision(6) << (ukupna_carina - 1) * 100 << endl;

    return 0;
}

