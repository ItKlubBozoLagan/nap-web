#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <set>
#include <thread>
#include <queue>
#include <deque>
#define _CRT_SECURE_NO_WARNINGS
#define all(x) x.begin(), x.end()
//#pragma GCC optimize("Ofast,unroll-loops")
//#pragma GCC target("avx,avx2,fma")
//vector<vector<int>> Ar(n, vector<int>(m, 0)); // n * m vector
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;


signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int t;
    cin >> t;
    for (int TC = 0; TC < t; TC++) {
        int n;
        int x;
        cin >> n >> x;
        int ans = INF;
        vector<int> Ar, Br,M;
        vector<int> CSA = { 0 };
        vector<int> CSB = { 0 };
        vector<int> CSM = { 0 };
        for (int i = 0;i < n;i++) {
            int a;
            cin >> a;
            Ar.push_back(a);
            CSA.push_back(CSA[i] + a);
        }
        for (int i = 0;i < n;i++) {
            int a;
            cin >> a;
            Br.push_back(a);
            CSB.push_back(CSB[i] + a);
        }
        for (int i = 0;i < n;i++) {
            int a = max(Ar[i], Br[i]);
            CSM.push_back(CSM[i] + a);
        }

        for (int i = 0;i < n+1;i++) {
            int base = CSM[i];
            int missing = x - base;
            auto it = lower_bound(all(CSA), x - base+CSA[i]);
            if (it != CSA.end()) {
                int dis = it - CSA.begin();
                ans = min(ans, 2*i + (dis-i));
            }
            it = lower_bound(all(CSB), x - base + CSB[i]);
            if (it != CSB.end()) {
                int dis = it - CSB.begin();
                ans = min(ans, 2 * i + (dis - i));
            }
        }

        if (ans == INF) { ans = -1; }
        cout << ans << "\n";
    }

}
