#include<bits/stdc++.h>
 
#define int long long
 
using namespace std;
 
const int MAXN = 2e5 + 10;
 
int a[MAXN], b[MAXN], cb, w[MAXN];
 
signed main(void){
        int n, i, j, ans = -1e18;
        cin >> n;
 
        for(i=1; i<=n; i++) cin >> a[i]; 
 
        if(n&1){
                for(i=2; i<=n; i+=2) b[++cb] = a[i];
                sort(&b[1], &b[cb]+1);
        }
        sort(&a[1], &a[n]+1);
        int s = 0;
        for (i=1; i<=n; i++) s += a[i], w[i] = w[i-1] + a[i];
        if (n&1) i = (n - 1) / 2 % 3; else i = (n / 2 + 1) % 3;
        for(; i<=n; i+=3){
                if(n>1 && (n&1) && i*2+1==n){
                        for(j=1; j<=i; j++) if(a[j] != b[j]) break;
                        if(j > i) ans = max(ans, s - (w[i] - a[i] + a[i+1]) * 2); else ans = max(ans, s - w[i] * 2);
                }
                else ans = max(ans,s-w[i]*2);
        }
        cout << ans;
        return 0;
}

