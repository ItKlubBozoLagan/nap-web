#include <bits/stdc++.h>
using namespace std;

int n, m;
char c[55][55];
int maxi = 0, kol = 0;

void check(string s) {
	int d = (int)s.size();
	for (int i = 0; i < d/2; i++) {
		if (s[i] != s[d-1-i]) return;
	}
	
	if (d > maxi) {
		maxi = d;
		kol = 1;
	}
	else if (d == maxi) kol++;
	
	return;
}

int main () {
	
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	cin >> n >> m;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			cin >> c[i][j];
		}
	}
	
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < m; j++) {
			string s = "";
			for (int k = i; k < n; k++) {
				if (c[k][j] == '#') break;
				s.push_back(c[k][j]);
				check(s);
			}
			s = "";
			for (int k = j; k < m; k++) {
				if (c[i][k] == '#') break;
				s.push_back(c[i][k]);
				if (k != j) check(s);
			}
		}
	}
	
	cout << maxi << " " << kol;
	
	return 0;
}
