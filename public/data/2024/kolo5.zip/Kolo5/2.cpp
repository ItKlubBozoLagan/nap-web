#include <bits/stdc++.h>
using namespace std;

int n;
int d;
char c[1005][1005];

int main () {
	
	ios_base::sync_with_stdio(false);
	cin.tie(0);
	
	cin >> n;
	d = 2+3*n;
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			c[i][j] = '.';
		}
	}
	
	for (int i = 0; i < n; i++) {
		c[0][1+n+i] = '#';
		c[1+n+i][0] = '#';
		c[d-1][1+n+i] = '#';
		c[1+n+i][d-1] = '#';
		
		c[1+i][1+2*n+i] = '#';
		c[1+2*n+i][1+i] = '#';
	
		c[1+i][n-i] = '#';
		c[d-2-i][d-1-n+i] = '#';
	}
	
	
	for (int i = 0; i < d; i++) {
		for (int j = 0; j < d; j++) {
			cout << c[i][j];
		}
		cout << "\n";
	}
	
	return 0;
}
