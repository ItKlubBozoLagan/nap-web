#include<bits/stdc++.h>

using namespace std;

int const MAX_N = 1005;
int const MAX_SCORE = 1005;
int const INF = 1e9;

int dp[MAX_N][2][2];
vector<int> sdp[MAX_N][MAX_SCORE];

vector<int> g[MAX_N];
int a[MAX_N];
int p[MAX_N];
int n;

int f(int cur, bool ok, bool parent);

int s(int cur, int score, int el) {
    if(score <= 0 && el == g[cur].size()) return 0;
    if(score <= 0 && el < g[cur].size()) return f(g[cur][el], true, false) + s(cur, score, el + 1);
    if(score > 0 && el == g[cur].size()) return -INF;

    if(sdp[cur][score][el] != -1) return sdp[cur][score][el];
 
    return sdp[cur][score][el]= max(f(g[cur][el], true, false) + s(cur, score, el + 1), f(g[cur][el], false, false) + s(cur, score - a[g[cur][el]], el + 1));
    
}

int f(int cur, bool ok, bool parent) {
    if(dp[cur][ok][parent] != -1) return dp[cur][ok][parent];
    int sol = 0;
    int sum = 0;
    for(int i : g[cur]) {
        sol += f(i, true, false);
        sum += a[i];
    }
    if(ok) {
        for(int i : g[cur]) {
            sol = max(sol, sol + f(i, true, true) - f(i, true, false));
        }
    }

    if(!ok) return dp[cur][ok][parent] = sol;

    int score = parent ? a[cur] - a[p[cur]] : a[cur];

    int psol = a[cur];
    for(int i : g[cur]) {
        psol += f(i, false, false);
    }
    sol = max(sol, psol);

    return dp[cur][ok][parent] = max(sol, a[cur] + s(cur, score, 0));
}


void solve() {
    cin >> n;
    for(int i = 1; i < n; ++i) {
        int x;
        cin >> x;
        g[x].push_back(i + 1);
        p[i + 1] = x;
    }

    for(int i = 0; i < n; ++i) cin >> a[i + 1];

    for(int i = 1; i < MAX_N; ++i) for(int j = 0; j < MAX_SCORE; ++j) for(int k = 0; k < g[i].size(); ++k) sdp[i][j].push_back(-1);

    cout << f(1, true, false) << endl;
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    memset(dp, -1, sizeof(dp));
    solve();
    return 0;
}
