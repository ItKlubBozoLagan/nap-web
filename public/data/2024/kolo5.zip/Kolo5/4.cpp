#include <bits/stdc++.h>
using namespace std;

#define X first
#define Y second

typedef long long ll;
typedef pair<int, int> pii;

const int N = 1e5 + 2;

int n, ans, mini;
vector<pii> v;

int main() {
	ios_base::sync_with_stdio(false); cin.tie(0);
	
	cin >> n;
	for (int i = 0; i < n; ++i) {
		int l, r; cin >> l >> r;
		v.push_back({l, r});
	}
	sort(v.begin(), v.end());
	mini = v[0].Y;

	for (pii& p : v) {
		if (mini <= p.X) {
			mini = p.Y; ++ans;
		} else mini = min(mini, p.Y);
	}
	
	cout << ans + 1 << "\n";

	return 0;
}
