#include <bits/stdc++.h>
using namespace std;
int main () {
	
	int n;
	cin >> n;
	if (n % 5 == 0) cout << n;
	else if ((n-1) % 5 == 0) cout << n-1;
	else if ((n+1) % 5 == 0) cout << n+1;
	else if ((n-2) % 5 == 0) cout << n-2;
	else cout << n+2;
	
	return 0;
}
