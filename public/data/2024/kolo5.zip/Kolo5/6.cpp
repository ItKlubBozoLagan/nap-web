#include<bits/stdc++.h>
#include <ext/pb_ds/detail/standard_policies.hpp>
#include <ext/pb_ds/assoc_container.hpp> // Common file
#include <ext/pb_ds/tree_policy.hpp> // Including tree_order_statistics_node_update

using namespace std;
using namespace __gnu_pbds;

const int MAXN = 2e5;

typedef long long ll;

/*template<
typename Key, // Key type
typename Mapped, // Mapped-policy
typename Cmp_Fn = std::less<Key>, // Key comparison functor
typename Tag = rb_tree_tag, // Specifies which underlying data structure to use
template<
typename Const_Node_Iterator,
typename Node_Iterator,
typename Cmp_Fn_,
typename Allocator_>
class Node_Update = null_node_update, // A policy for updating node invariants
typename Allocator = std::allocator<char> > // An allocator type
class tree;
*/
typedef tree<pair<ll, int>, null_type, std::less<pair<ll, int>>, rb_tree_tag, tree_order_statistics_node_update> OrderedSet;

ll n, k;
ll arr[MAXN];

//map<ll, int> id;

bool check (ll bnd){
    OrderedSet pref;
    pref.insert ({0, 0});
    ll cur = 0;
    ll uk = 0;
    for (int i = 0; i < n; ++i){
        cur += arr[i];
        ll val = cur-bnd;

        // find how many elems from pref are < val
        ll cnt = pref.order_of_key({val, -1});
        uk += cnt;
        pref.insert({cur, i});
    }

    return uk>=k;
}

int main(){
    cin >>n >>k;
    ll sum = 0;
    ll rsum = 0;
    for (int i = 0; i < n; ++i){
        cin >>arr[i];
        if (arr[i] > 0) sum += arr[i];
        else rsum += arr[i];
    }

    ll l = rsum, r = sum;

    while (l < r){
        ll mid = (l+r)/2;
        if (l+r < 0){
            mid = (l+r-1)/2;
        }

        if (check (mid)){
            l = mid+1;
        }else{
            r = mid;
        }
    }
    cout <<l <<"\n";
return 0;
}

