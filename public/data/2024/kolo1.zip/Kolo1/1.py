print(2846 * int(input()))
