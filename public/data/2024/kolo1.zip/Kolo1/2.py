l = [int(x) for x in input().split()]
l2 = [int(x) for x in input().split()]

good = 1
for i in l:
    if l.count(i) != l2.count(i):
        good = 0
mx = 0
mn = 1000000000
p1 = 0
p2 = 0
id = 0
for i in l2:
    if mx < i:
        mx = i
        p1 = id
    if mn > i:
        mn = i
        p2 = id
    id += 1
if p1 < p2:
    good = 0
print (good)
