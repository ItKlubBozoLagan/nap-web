#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <set>
#include <queue>
#include <deque>
#define _CRT_SECURE_NO_WARNINGS
//#pragma GCC optimize("Ofast,unroll-loops")
//#pragma GCC target("avx,avx2,fma")
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;

struct segtree
{
    vector<int> tree; // sum, gcd, min, max

    segtree(int n, vector<int>& A) : tree(2 * n)
    {
        for (int i = 0; i < n; i++)
            tree[n + i] = A[i];
        for (int i = n - 1; i > 0; i--) {
            //tree[i] = max(tree[i << 1], tree[i << 1 | 1]); // gcd, min, max
            tree[i] = tree[i << 1]+tree[i << 1 | 1];
        }
    }
    int query(int i, int j) // inclusive
    {
        i += tree.size() / 2;
        j += tree.size() / 2;

        int my = 0; // if gcd or sum

        while (i <= j)
        {
            if (i & 1) {
                //my = max(my, tree[i++]);  // gcd, min, max
                my = my + tree[i++];
            }

            if (!(j & 1)) {
                //my = max(my, tree[j--]);  // gcd, min, max
                my = my + tree[j--];
            }

            i >>= 1;
            j >>= 1;
        }
        return my;
    }
    void update(int pos, int value)
    {
        pos += (int)tree.size() / 2;
        tree[pos] = value;

        while (pos > 1) {
            pos >>= 1;
            //tree[pos] = max(tree[pos << 1], tree[pos << 1 | 1]); //gcd, min, max
            tree[pos] = tree[2 * pos] + tree[2 * pos + 1];// sum
        }
    }

};

signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n, q;
    cin >> n >> q;

    vector<int> Ar,Empty(n,0);

    for (int i = 0; i < n; i++) {
        int a;
        cin >> a;
        Ar.push_back(a);
    }

    vector<segtree> SegForest(20, segtree(n, Empty));
    for (int bit = 0; bit < 31; bit++) {
        for (int i = 0; i < n; i++) {
            if (Ar[i] & (1 << bit)) {
                SegForest[bit].update(i, 1);
            }
        }
    }

    for (int i = 0; i < q; i++) {
        char type;
        cin >> type;
        if (type == '?') {
            int l, r;
            cin >> l >> r;
            l--;
            r--;
            int range = r - l + 1;
            int ans = 0;
            for (int bit = 0; bit < 20; bit++) {
                int ones = SegForest[bit].query(l, r);
                int zeros = range - ones;
                ans += (ones * zeros) * (1 << bit);
            }
            cout << ans << "\n";
        }
        else {
            int x, a;
            cin >> x >> a;
            x--;
            for (int bit = 0; bit < 20; bit++) {
                if (a & (1 << bit)) {
                    SegForest[bit].update(x, 1);
                }
                else {
                    SegForest[bit].update(x, 0);
                }
            }
        }
    }

}
