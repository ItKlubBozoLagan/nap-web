#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

const int mod = 1e9+7;
const int MAXN = 3e5+7;

#define x first
#define y second

typedef pair<ld, ld> point;

mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());
int randint (int l, int r){
    return l+rng ()%(r-l+1);
}

int n;
point ar[MAXN];

ld dist (point p1, point p2){
    return sqrt ((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}

int res[MAXN];

void rek (int lx, int hx, int ly, int hy){
    if (ly > hy)return;
    int x = (ly+hy)/2;
    ld md = 0.0;
    int mp = 0;
    for (int i = lx; i <= hx; ++i){
        if (i <= x)continue;
        ld d = dist (ar[i%n], ar[x]);
        if (d > md){
            md = d;
            mp = i;
        }
    }
    res[x] = mp%n;
    rek(lx, mp, ly, x-1);
    rek(mp, hx, x+1, hy);

}



int main(){
    cin >> n;
    ld md = 0;
    int mp = 0;
    for (int i = 0; i < n; i++) {
        cin>> ar[i].x >> ar[i].y;
    }

    rek (0, 2*n-1, 0, n-1);
    ld sol = 0;

    for (int i = 0; i < n; ++i){
          cout << fixed << setprecision(6) << dist (ar[res[i]], ar[i])<<" ";
        sol = sol + dist (ar[res[i]], ar[i]);
    }
    cout <<"\n";

return 0;
}
