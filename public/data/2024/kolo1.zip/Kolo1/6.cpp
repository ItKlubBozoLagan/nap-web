#include <bits/stdc++.h>
using namespace std;

const int MOD = 1e9+7;

int n, m, k, a, b;
char c;
int dp[1005][11][(1 << 10)+5];
int los[1005][11][5];

int add(int x, int y) {
	if (x+y >= MOD) return x+y-MOD;
	return x+y;
}

int rek(int x, int y, int mask) {
	if (y == m) return rek(x+1, 0, mask);

	if (x == n) {
		return 1;
	}

	int &ret = dp[x][y][mask];
	if (ret != -1) return ret;
	if ((mask&(1 << y)) == 0) ret = rek(x, y+1, mask);
	else ret = rek(x, y+1, mask-(1 << y));

	if (y+1 < m) {
		if ((mask&(1 << y)) == 0) {
			if (!los[x][y][0] && !los[x][y][1]) ret = add(ret, rek(x, y+2, mask|((1 << y) + (1 << (y+1)))));

			if ((mask&(1 << (y+1))) == 0) {
				if (!los[x][y][0] && !los[x-1][y][1]) ret = add(ret, rek(x, y+1, mask|((1 << y) + (1 << (y+1)))));
				if (!los[x-1][y][1] && !los[x][y+1][0]) ret = add(ret, rek(x, y+2, mask|(1 << (y+1))));

				if (y+2 < m && (mask&(1 << (y+2))) == 0) {
					if (!los[x][y][0] && !los[x][y][1] && !los[x-1][y+1][1] && !los[x][y+2][0]) {
						ret = add(ret, rek(x, y+3, mask|((1 << y) + (1 << (y+1)) + (1 << (y+2)))));
					}
				}
			}
		}

		if ((mask&(1 << (y+1))) == 0) {
			if (!los[x][y][1] && !los[x][y+1][0]) ret = add(ret, rek(x, y+2, mask|((1 << y) + (1 << (y+1)))));
		}
	}

	return ret;
}

int main () {

	ios_base::sync_with_stdio(false);
	cin.tie(0);

	cin >> n >> m >> k;
	for (int i = 0; i < k; i++) {
		cin >> a >> b >> c;
		a--, b--;
		if (c == 'U') {
			los[a][b][0] = 1;
			los[a-1][b][2] = 1;
		}
		else if (c == 'R') {
			los[a][b][1] = 1;
			los[a][b+1][3] = 1;
		}
		else if (c == 'D') {
			los[a][b][2] = 1;
			los[a+1][b][0] = 1;
		}
		else if (c == 'L') {
			los[a][b][3] = 1;
			los[a][b-1][1] = 1;
		}
	}

	memset(dp, -1, sizeof dp);
	cout << rek(1, 0, 0);

	return 0;
}
