def komunikacija(n, poruke):
    odgovorio_prvi = False
    odgovorio_drugi = False
    znanje_prvi = {}
    znanje_drugi = {}
    izjave = []
    
    prosla_pitanja = []

    first = True
    for poruka in poruke:
        pitanja = []  
        lokalno_znanje_prvi = {}
        lokalno_znanje_drugi = {}
        
        flag = True

        trenutne_izjave = []

        for red in poruka:
            if red.endswith("?"):
                pitanja.append(red[:-1])
                izjave.append(red[:-1])
                if first:
                    znanje_prvi[red[:-1]] = "NEZNA"
                else:
                    znanje_drugi[red[:-1]] = "NEZNA"
            elif ": " in red:
                tekst, odgovor = red.split(": ")
                izjave.append(tekst)
                trenutne_izjave.append(tekst)
                znanje_prvi[tekst] = odgovor
                znanje_drugi[tekst] = odgovor
        
        for i in prosla_pitanja:
            if i not in trenutne_izjave:
                if first:
                    znanje_prvi[i] = "NEZNA"
                else:
                    znanje_drugi[i] = "NEZNA"
            else:
                break
        prosla_pitanja = pitanja
        first = not first
    rezultat = []
    for izjava in sorted(list(set(izjave))):
        
        if izjava in znanje_prvi:
            rez_prvi = znanje_prvi[izjava]
        else:
            rez_prvi = "NEODREDIVO"
        if izjava in znanje_drugi:
            rez_drugi = znanje_drugi[izjava]
        else:
            rez_drugi = "NEODREDIVO"
        
        rezultat.append(f"{izjava}: {rez_prvi} {rez_drugi}")
    
    return rezultat


n = int(input())
poruke = []

for _ in range(n):
    ni = int(input())
    poruka = [input().strip() for _ in range(ni)]
    poruke.append(poruka)

rezultati = komunikacija(n, poruke)
for r in rezultati:
    print(r)
