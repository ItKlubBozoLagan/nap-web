#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <set>
#include <queue>
#include <deque>
#define _CRT_SECURE_NO_WARNINGS
//#pragma GCC optimize("Ofast,unroll-loops")
//#pragma GCC target("avx,avx2,fma")
using namespace std;
#define ll long long
#define int ll
#define ld double long
const int MOD = 1e9 + 7;
const int N = 2e5 + 5;
const ld pi = 3.141592653589793238;
const ll INF = 9e18;
 
 
struct DSU {
 
    vector<int> parent, size;
 
    int discomp = 0; //disconnected components
 
 
    void make_set(int v) {
        parent[v] = v;
        size[v] = 1;
        discomp++;
    }
 
    int find_set(int v) {
        if (v == parent[v])
            return v;
        return parent[v] = find_set(parent[v]);
    }
 
    void union_sets(int a, int b) {
        a = find_set(a);
        b = find_set(b);
        if (a != b) {
            if (size[a] < size[b])
                swap(a, b);
            parent[b] = a;
            size[a] += size[b];
            size[b] = 0;
            discomp--;
        }
    }
    DSU(int n) {
        parent.resize(n + 1);
        size.resize(n + 1);
        for (int i = 1; i <= n; i++) {
 
            make_set(i);
 
        }
    }
};
 
 
//biggest k disconnected components
int DirCon[N];
int Ksum = 0;
multiset<int> KMost, Others;
DSU graph = DSU(1);
 
void Unite(int u, int v) {
    //math U to V'd neighbours
    int size1 = graph.size[u];
    int size2 = graph.size[v];
 
    if (size1 > size2) {
        swap(size1, size2);
    }
    // two not in the sum
    
    if (KMost.find(size1) == KMost.end()&& KMost.find(size2) == KMost.end()) {
        int Kth = *KMost.begin();
        if (size1 + size2 > Kth) {
            Ksum -= Kth;
            Ksum += size1 + size2;
            Others.insert(*KMost.begin());
            KMost.erase(KMost.begin());
            KMost.insert(size1 + size2);
        }
        else {
            Others.insert(size1 + size2);
        }
        Others.erase(Others.find(size1));
        Others.erase(Others.find(size2));
    }
    //one who is in the sum, other who isnt
    else if (Others.find(size1) != Others.end()) {
        Ksum += size1;
        KMost.insert(size1 + size2);
        KMost.erase(KMost.find(size2));
        Others.erase(Others.find(size1));
    }
    //both are in the sum
    else {
        KMost.insert(size1 + size2);
        KMost.erase(KMost.find(size1));
        KMost.erase(KMost.find(size2));
        auto it = Others.end();
        if (!Others.empty()) {
            it--;
            Ksum += *it;
            KMost.insert(*it);
            Others.erase(it);
        }
    }
    graph.union_sets(u, v);
 
}
 
 
 
signed main()
{
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    int n, m, k;
    cin >> n >> m >> k;
    graph = DSU(n);
    vector<int> Ans;
    Ksum = k;
    for (int i = 0; i < n; i++) {
        if (i < k) {
            KMost.insert(1);
        }
        else {
            Others.insert(1);
        }
    }
 
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        //find what's dirrectly connected to each and their representants
        int dirU = DirCon[u];
        dirU = graph.find_set(dirU);
        int repV = graph.find_set(v);
 
        if (dirU != 0) {
            if (dirU != repV) {
                Unite(dirU, repV);
            }
        }
        else { DirCon[u] = v; }
 
        int repU = graph.find_set(u);
        int dirV = DirCon[v];
        dirV = graph.find_set(dirV);
 
        if (dirV != 0) {
            if (dirV != repU) {
                Unite(dirV, repU);
            }
        }
        else{ DirCon[v] = u; }
        Ans.push_back(Ksum);
 
    }
    for (int i = 0; i < m; i++) {
        cout << Ans[i] << "\n";
    }
}

