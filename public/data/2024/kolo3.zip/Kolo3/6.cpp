#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

template <typename T> bool chmin(T &a, T b) { if (a > b) { a = b; return 1; } return 0; }

const int inf = 2e9 + 42;
const int N = 1e5 + 42, M = 5;

int a[N][M], b[N][M], w[N], ii[N], aa[N * M];
ll msk[N * M];

int solve(){
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            cin >> a[i][j];
        }
        cin >> w[i];
    }

    int pt = 0;
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            aa[pt++] = a[i][j];
        }
    }
    sort(aa, aa + pt);
    pt = unique(aa, aa + pt) - aa;
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            a[i][j] = lower_bound(aa, aa + pt, a[i][j]) - aa;
        }
    }
    iota(ii, ii + n, 0);
    sort(ii, ii + n, [&](int i, int j) { return w[i] < w[j]; });
    sort(w, w + n);
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            b[i][j] = a[ii[i]][j];
        }
    }
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < m; ++j){
            a[i][j] = b[i][j];
        }
    }

    int ans = inf;
    for (int l = 0; l < n; l += 64){
        int r = min(l + 64, n);
        for (int i = l; i < r; ++i){
            for (int j = 0; j < m; ++j){
                msk[a[i][j]] |= 1ULL << i - l;
            }
        }
        for (int i = 0; i < n; ++i){
            ll have = 0;
            for (int j = 0; j < m; ++j){
                have |= msk[a[i][j]];
            }
            int pos = __builtin_ctzll(have ^ ll(-1));
            if (pos != r - l) chmin(ans, w[i] + w[l + pos]);
        }
        for (int i = l; i < r; ++i){
            for (int j = 0; j < m; ++j){
                msk[a[i][j]] = 0;
            }
        }
    }
    if (ans != inf) cout << ans; else cout << -1; 
    return 0;
}

int main(){
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    solve();
    return 0;
}
