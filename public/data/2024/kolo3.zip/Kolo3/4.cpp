#include<bits/stdc++.h>

using namespace std;

int n, m;
bool mat[3000][3000];

int dp[3000];
int cnt [3000][3000];
void roll(bool &a, bool &b, bool &c, bool &d)
{
    int temp = a;
    a = b;
    b = c;
    c = d;
    d = temp;
}

int solve (){
    for (int i = 0; i < n; ++i){
        dp[i] = 0;
        for (int j = 0; j < n; ++j){
            cnt[i][j] = 0;
        }
    }
    for (int i = -(n-1); i < n; ++i){
        for (int j = 0; j < n; ++j){
            if (i+j < 0 || i+j >= n)continue;
            if (i+j == 0 || j == 0)cnt[j][i+j] = mat[j][i+j];
            else cnt[j][i+j] = (cnt[j-1][i+j-1]+1)*mat[j][i+j];
        }
    }

    int res = 0;
    for (int i = 0; i < n; ++i){
        for (int j = 0; j < n; ++j)dp[j] = 0;
        for (int j = 0; j < n; ++j){
            if (i == 0 || j == 0){
                dp[j] = mat[i][j];
                res = max (res, dp[j]);
                continue;
            }
            dp[j] = min (cnt[i][j], dp[j-1]+1);
            res = max (res, dp[j]);
        }
    }

    return res;
}

int main(){
    ios_base::sync_with_stdio(false);
    cin.tie(nullptr);
    cin >>n;
    for (int i = 0; i < n; ++i){
        string s;
        cin >>s;
        for (int j = 0; j < n; ++j){
            mat[i][j] = (s[j] == '1');
        }
    }
    int sol = 0;
    int best = 0;
    for (int k = 0; k < 4; ++k){
        int tmp = solve();
        if (tmp > sol){
            sol = tmp;
            best = k;
        }
        sol = max (sol, solve ());
        for(int i=0; i<n/2; i++){
            for(int j=0; j<(n+1)/2; j++){
                roll(mat[i][j], mat[n-1-j][i], mat[n-1-i][n-1-j], mat[j][n-1-i]);
            }
        }

    }
    //cout <<best <<"\n";
    cout <<sol <<"\n";
return 0;
}

/*
10
1 0 0 0 0 0 1 0 0 0
1 1 0 0 0 0 1 1 0 0
0 1 1 1 1 0 1 1 1 0
0 0 1 1 1 0 0 0 0 0
0 0 0 1 1 0 0 0 0 0
0 0 0 0 1 1 1 0 0 0
0 0 0 0 1 1 1 0 0 0
0 0 0 0 1 1 1 0 0 0
0 0 0 0 0 0 0 0 0 0
0 0 0 0 0 0 0 0 0 0

0
9
12
20
23
28
43
46
345
467


*/
