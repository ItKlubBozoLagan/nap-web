#include <bits/stdc++.h>
using namespace std;
 
const int N = 5e4 + 2;
 
int n, sub[N];
vector<int> adj[N];
bool ban[N];
 
void prep(int node, int anc) {
	sub[node] = 1;
	for (int x : adj[node]) {
		if (x == anc || ban[x]) continue;
		prep(x, node);
		sub[node] += sub[x];
	}
}
 
bool find(int node, int anc, int tar) {
	bool ret = node == tar;
	for (int x : adj[node]) {
		if (x == anc || ban[x]) continue;
		ret |= find(x, node, tar);
	}
	return ret;
}
 
void solve(int node) {
	prep(node, node);
	int centroid = node;
	bool found = 1;
	while (found) {
		found = 0;
		for (int x : adj[centroid]) {
			if (!ban[x] && sub[x] * 2 > sub[centroid]) {
				sub[centroid] -= sub[x];
				sub[x] += sub[centroid];
				centroid = x;
				found = 1;
				break;
			}
		}
	}
	cout << centroid + 1 << endl;
	int maks; cin >> maks;
	if (maks == -1) return ;
	--maks;
	ban[centroid] = 1;
	for (int x : adj[centroid]) {
		if (!ban[x] && find(x, x, maks)) solve(x);
	}
}
 
int main() {
	ios_base::sync_with_stdio(false); cin.tie(0);
	
	cin >> n;
	for (int i = 1; i < n; ++i) {
		int u, v;
		cin >> u >> v, --u, --v;
		adj[u].push_back(v);
		adj[v].push_back(u);
	}
	
	solve(0);
 
	return 0;
}

