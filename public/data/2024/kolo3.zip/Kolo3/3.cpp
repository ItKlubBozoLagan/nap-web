#include<bits/stdc++.h>

using namespace std;

int n;
int c[1001];

int mini = 1e9, maxi = 0;
char mat[1001][1001];
int main(){
    cin >>n;
    for (int i = 0; i < n; ++i){
        cin >>c[i];
        c[i] /= 10;
        mini = min (c[i], mini);
        maxi = max (c[i], maxi);
    }
    for (int i = mini; i <= maxi; ++i){
        for (int j = 0; j < n; ++j){
            mat[i][j] = '.';
        }
    }
    mat[c[0]][0] = '*';
    for (int i = 1; i < n; ++i){
        int lst = c[i-1];
        int cur = c[i];
        if (lst == cur) {
            mat[cur][i] = '*';
            continue;
        }
        int add = abs(cur-lst)/(cur-lst);
        for (int j = lst+add; j != cur+add; j += add){
            mat[j][i] = '*';
        }
    }
    int tmp = maxi*10;
    int cnt = 0;
    while (tmp){
        ++cnt;
        tmp /= 10;
    }

    for (int i = maxi; i >= mini; --i){
        tmp = i*10;
        int cnt2 = 0;
        while (tmp){
            ++cnt2;
            tmp /= 10;
        }
        if (cnt2 == 0)cnt2 = 1;
        for (int j = 0; j < cnt-cnt2; ++j)cout <<" ";

        cout <<i*10;
        cout <<'|';

        for (int j = 0; j < n; ++j)cout <<mat[i][j];
        cout <<"\n";
    }

return 0;
}
/*

7
80 110 110 110 120 70 0
*/


