#include<bits/stdc++.h>

using namespace std;

string s;
int n;

int main(){
    cin >>n;
    cin >>s;
    int maxi = 0;
    for (int i = 0; i < n; ++i){
        int cnt = 0;
        while (i < n && s[i] == '.'){
            ++i;
            ++cnt;
        }
        maxi = max (maxi, cnt);
    }
    cout <<maxi <<"\n";
return 0;
}

